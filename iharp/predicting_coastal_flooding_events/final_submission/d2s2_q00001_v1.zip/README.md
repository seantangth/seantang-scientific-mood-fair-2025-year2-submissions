# D2 station-quota consensus submission

- source_runs: `f1push_ranker_v1_20260214_075444, a2_balanced_xgb_v1_20260214_113741, b1_groupdro_xgb_v1_20260214_122519, b2_union_xgb_v1_20260214_130826, a3_focal_xgb_v1_20260215_122316`
- force_lowest_q_to_neg: `1e-05`
- neg_prior_alpha: `2.0`
- policy: station-quota consensus low-risk selection
